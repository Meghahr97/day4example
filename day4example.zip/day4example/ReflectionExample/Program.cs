﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
using ClassLibrary1;

namespace ReflectionExample
{
    class Program
    {
        static void Main(string[] args)
        {
           // Assembly t = Assembly.GetAssembly(typeof(Employee));
            Type tt = typeof(Employee);
            ConstructorInfo[] ci = tt.GetConstructors();
            foreach (var c in ci)
            {
                Console.WriteLine("constructor name;" + c.Name);
                Console.WriteLine("is public: " + c.IsPublic);
                ParameterInfo[] pi = c.GetParameters();
                foreach (var p in pi)
                {
                    Console.WriteLine("parameter type" + p.ParameterType);
                    Console.WriteLine("parameter position:" + p.Position);
                    Console.WriteLine("default value for parameter" + p.DefaultValue);
                }
                MethodInfo []mi = tt.GetMethods();
                foreach(var m in mi)
                {
                    Console.WriteLine("method Name:" + m.Name);
                    Console.WriteLine("module name:" + m.Module);
                    Console.WriteLine("return type:" + m.ReturnType);
                        Console.WriteLine("ispublic:" + m.IsPublic);
                }
                MemberInfo []fi = tt.GetMembers();
                foreach(var f in fi)
                {
                    Console.WriteLine(f.Name);
                    Console.WriteLine(f.Module);
                    Console.WriteLine(f.MemberType);
                    Console.WriteLine(f.DeclaringType);
                }
                Console.WriteLine("*************");


            }
        }
    }
}
